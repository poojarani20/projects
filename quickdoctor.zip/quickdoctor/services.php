<!doctype html>
<html>
<head>
<title>Quick Doctorin</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php include("header-style.php"); ?>
</head>
<body>
<section class="serach-wrapper-inner">
  <?php include("nav.php"); ?>
</section>
<section class="content-block minheight">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
      
      <h1>Our Services</h1>
        
      </div>
      
    </div>
  </div>
</section>

<?php include("footer.php"); ?>
</body>
</html>
